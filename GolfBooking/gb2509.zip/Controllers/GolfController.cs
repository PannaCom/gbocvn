﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
using Newtonsoft.Json;
using GolfBooking.Models;
using System.Data;
using System.Collections;
namespace GolfBooking.Controllers
{
    public class GolfController : Controller
    {
        //
        // GET: /Golf/
        private golfbookingEntities db = new golfbookingEntities();
        public ActionResult Index(string name, int? page)
        {
            //return View(db.provinces.Where(o=>o.deleted==0).OrderBy(o=>o.country_id).ThenBy(o=>o.name).ToList());
            if (name == null) name = "";
            ViewBag.name = name;
            var p = (from q in db.golves where q.name.Contains(name) && q.deleted == 0 select q).OrderBy(o => o.name).Take(100);
            int pageSize = 25;
            int pageNumber = (page ?? 1);
            return View(p.ToPagedList(pageNumber, pageSize));
        }
        public ActionResult List(string name,int? region,int? page)
        {
            //return View(db.provinces.Where(o=>o.deleted==0).OrderBy(o=>o.country_id).ThenBy(o=>o.name).ToList());
            if (name == null) name = "";
            if (region == null) region = -1;
            ViewBag.name = name;
            ViewBag.region = region;
            var p = db.golves.Where(o=>o.name.Contains(name)).Where(o=>o.deleted==0);//(from q in db.golves where q.name.Contains(name) && q.deleted == 0 select q).OrderBy(o => o.name).Take(100);
            if (region != -1) p = p.Where(o => o.region_id == region);
            p = p.OrderBy(o => o.name).Take(100);
            int pageSize = 8;
            int pageNumber = (page ?? 1);
            ViewBag.page = pageNumber;
            ViewBag.header_course_list = Config.getRegionById((int)region) + " Golf Course";
            
            return View(p.ToPagedList(pageNumber, pageSize));
        }
        public ActionResult View(int id) {
            golf golf = db.golves.Find(id);
            if (golf == null)
            {
                return HttpNotFound();
            }
            ViewBag.sdes = Config.smoothDes(golf.des);
            ViewBag.des = golf.des;
            string gallery = "";
            var p = (from q in db.golf_image where q.golf_id == id select q).Take(3).ToList();
            for (int i = 0; i < p.Count; i++) { 
                gallery+="<li><a href=\""+Config.domain+p[i].image+"\" rel=\"lightbox\" class=\"link-image\"><img class=\"wp-image\" src=\""+Config.domain+p[i].image+"\" alt=\""+golf.name+"\" style=\"width:70px;height:70px;\"/></a></li>";
            }
            ViewBag.gallery = gallery;
            string golf_course_list = "";
            var p2 = (from q in db.golves where q.region_id == golf.region_id && q.deleted==0 select q).Take(6).ToList();
            for (int j = 0; j < p2.Count; j++) { 
                golf_course_list+="<div class=\"panel panel-default\">";
				golf_course_list+=" <div class=\"panel-heading\">";
				golf_course_list+="<h6 class=\"panel-title\" style=\"font-size:12px;\">";
				golf_course_list+="<a class=\"accordion-toggle\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseOne\">"+p2[j].name+"</a>";
				golf_course_list+=" </h6>";
				golf_course_list+="	</div>";
				golf_course_list+=" <div id=\"collapseOne\" class=\"panel-collapse collapse in\">";
				golf_course_list+="		<div class=\"panel-body\" style=\"font-size:12px;\">";
                golf_course_list += Config.smoothDesSmall(p2[j].des) + "..<a href=\"/golf/view/" + p2[j].id + "\">đọc tiếp</a>";
				golf_course_list+="			    	</div>";
				golf_course_list+="			    </div>";
                golf_course_list += "		</div>";
            }
            ViewBag.golf_course_list = golf_course_list;
            ViewBag.header_course_list = Config.getRegionById((int)golf.region_id) + " Golf";
            return View(golf);
        }
        public ActionResult Create(int? id) {
            ViewBag.id = id;
            if (id == null)
            {
                ViewBag.id = 0;
                ViewBag.country_id = -1;
                ViewBag.province_id = -1;
                ViewBag.region_id = 1;
                ViewBag.name = "";
                ViewBag.des = "";
                ViewBag.image = "";
                ViewBag.address = "";
                ViewBag.lon = "";
                ViewBag.lat = "";
                ViewBag.tech_des = "";
                ViewBag.score_board_image = "";
            }
            else
            {
                var p = db.golves.Where(o => o.id == id).FirstOrDefault();
                if (p != null) {
                    ViewBag.name = p.name;
                    ViewBag.des = p.des;
                    ViewBag.country_id = p.country_id;
                    ViewBag.province_id = p.province_id;
                    ViewBag.region_id = p.region_id;
                    ViewBag.image = p.image;
                    ViewBag.address = p.address;
                    ViewBag.lon = p.lon;
                    ViewBag.lat = p.lat;
                    ViewBag.tech_des = p.tech_des;
                    ViewBag.score_board_image = p.score_board_image;
                    
                }
            }
            DateTime fromDate = DateTime.Now;
            DateTime toDate = DateTime.Now.AddDays(30);
            ViewBag.fromDate = String.Format("{0:yyyy-MM-dd}", fromDate);
            ViewBag.toDate = String.Format("{0:yyyy-MM-dd}", toDate);  
            return View();
        }
        public ActionResult Test() {

            return View();
        }
        [HttpPost]
        [AcceptVerbs(HttpVerbs.Post)]
        public string UploadImageProcess(HttpPostedFileBase file)
        {
            string physicalPath = HttpContext.Server.MapPath("../" + Config.GolfImagePath + "\\");
            string nameFile = String.Format("{0}.jpg", Guid.NewGuid().ToString());
            int countFile = Request.Files.Count;
            string fullPath = physicalPath + System.IO.Path.GetFileName(nameFile);
            for (int i = 0; i < countFile; i++)
            {
                if (System.IO.File.Exists(fullPath))
                {
                    System.IO.File.Delete(fullPath);
                }
                Request.Files[i].SaveAs(fullPath);
                break;
            }
            //string ok = resizeImage(Config.imgWidthNews, Config.imgHeightNews, fullPath, Config.NewsImagePath + "/" + nameFile);
            return Config.GolfImagePath + "/" + nameFile;
        }
        [HttpPost]
        [AcceptVerbs(HttpVerbs.Post)]
        public string UploadImageProcessGi(HttpPostedFileBase file)
        {
            string physicalPath = HttpContext.Server.MapPath("../" + Config.GolfImagePath + "\\");
            string nameFile = String.Format("{0}.jpg", Guid.NewGuid().ToString());
            int countFile = Request.Files.Count;
            string fullPath = physicalPath + System.IO.Path.GetFileName(nameFile);
            ArrayList list = new ArrayList();
            for (int i = 0; i < countFile; i++)
            {
                nameFile = String.Format("{0}.jpg", Guid.NewGuid().ToString());
                fullPath = physicalPath + System.IO.Path.GetFileName(nameFile);
                if (System.IO.File.Exists(fullPath))
                {
                    System.IO.File.Delete(fullPath);
                }
                Request.Files[i].SaveAs(fullPath);
                list.Add(Config.GolfImagePath + "/" + nameFile);
            }
            return JsonConvert.SerializeObject(list);
        }
        [HttpPost]
        [ValidateInput(false)]
        public string Update_Golf(string name, string des,int country_id,int province_id,int region_id, string image, string address, double? lon, double? lat, string tech_des, string score_board_image,int id)
        {
            try
            {
                if (id == 0)
                {
                    golf gl = new golf();
                    gl.name = name;
                    gl.des = des;
                    gl.country_id = country_id;
                    gl.province_id = province_id;
                    gl.region_id = region_id;
                    gl.image = image;
                    gl.address = address;
                    gl.lon = lon;
                    gl.lat = lat;
                    gl.tech_des = tech_des;
                    gl.score_board_image = score_board_image;
                    gl.geo = Config.CreatePoint(lat, lon);
                    gl.deleted = 0;
                    db.golves.Add(gl);
                    db.SaveChanges();
                    return gl.id.ToString();
                }
                else
                {
                    golf gl = db.golves.Find(id);
                    gl.name = name;
                    gl.des = des;
                    gl.country_id = country_id;
                    gl.province_id = province_id;
                    gl.region_id = region_id;
                    gl.image = image;
                    gl.address = address;
                    gl.lon = lon;
                    gl.lat = lat;
                    gl.tech_des = tech_des;
                    gl.score_board_image = score_board_image;
                    gl.geo = Config.CreatePoint(lat, lon);
                    gl.deleted = 0;
                    db.Entry(gl).State = EntityState.Modified;
                    db.SaveChanges();
                    return id.ToString();
                }
            }
            catch (Exception ex) {
                return "0";
            }
            //return "1";
        }
        public string getGI(int id) {
            var p = (from q in db.golf_image where q.golf_id == id select q.image).ToList();
            ArrayList list=new ArrayList();
            try
            {
                int i;
                if (p.Count > 0)
                {
                    for(i=0;i<p.Count;i++)
                    {
                        list.Add(p[i]);
                    }
                }
                return JsonConvert.SerializeObject(list);
            }
            catch (Exception ex) {
                return "0";
            }
        }
        public string updateGI(int count, int id) {
            try
            {
                db.Database.ExecuteSqlCommand("delete from golf_image where golf_id=" + id);
                if (id != 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        string name = Request.Form["name_" + i].ToString();
                        if (name != "" && name != null) {
                            golf_image gi = new golf_image();
                            gi.golf_id = id;
                            gi.image = name;
                            db.golf_image.Add(gi);
                            db.SaveChanges();
                        }
                    }
                }
                return "1";
            }
            catch (Exception ex) {
                return "0";
            }
        }
    }
}
